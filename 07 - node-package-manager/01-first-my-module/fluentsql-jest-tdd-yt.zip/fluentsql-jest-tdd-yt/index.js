import FluentSQLBuilder from "./src/fluentSQL.js";

export default FluentSQLBuilder
